# Extinction_2_Player

This is the 2 player verision of the game Extinction that is available in the repo: https://github.com/sumqwerty/Extinction

Extinction is a advancement of the shoot-em up game my "kidscancode", this game has more guns, and UI, diffrent players to choose from This game is developed in python, using the pygame module for player movement and game logic, and pytmx for integrating Tiled Map editor for making levels.

Its still under development, and i want to include a boos, one other levels too!!
